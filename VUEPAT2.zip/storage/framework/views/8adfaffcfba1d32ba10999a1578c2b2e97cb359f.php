<?php $__env->startSection('content'); ?>

<v-container fluid grid-list-md text-xs-center>

  <div v-if="$store.getters.user.id_usuario == 1">
    <home></home> 
  </div>
  <div v-else>
    <registro></registro> 
  </div>

</v-container>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>