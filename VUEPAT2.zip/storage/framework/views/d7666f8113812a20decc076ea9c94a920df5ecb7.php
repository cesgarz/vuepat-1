<?php $__env->startSection('content'); ?>

    <v-container fluid grid-list-md text-xs-center>

     <v-list class="warning">
        <v-list-tile>
                
            <v-list-tile-action>
                <v-icon>build</v-icon>
            </v-list-tile-action>

            <v-list-tile-content>
                <v-list-tile-title>EN CONSTRUCCION</v-list-tile-title>
            </v-list-tile-content>

        </v-list-tile>
    </v-list>
    </v-container>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>