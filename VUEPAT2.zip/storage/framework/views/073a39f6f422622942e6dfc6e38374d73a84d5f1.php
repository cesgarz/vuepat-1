<?php $__env->startSection('content'); ?>

    <v-container fluid grid-list-md text-xs-center>

    <banco-lista></banco-lista>

    </v-container>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>