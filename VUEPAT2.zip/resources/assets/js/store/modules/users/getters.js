export default {
  selectedUser: state => state.selected_user,
  users: state => state.users
}
