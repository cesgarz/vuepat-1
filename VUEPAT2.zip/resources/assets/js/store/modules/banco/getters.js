export default {
  selectedUser: state => state.selected_banco,
  users: state => state.banco
}
