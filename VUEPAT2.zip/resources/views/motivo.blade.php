@extends('layouts.app')
@section('content')

<v-container fluid grid-list-md text-xs-center>
  
  
  <motivo-lista> </motivo-lista>
  
  
</v-container>
@endsection
