@extends('layouts.app')
@section('content')

<v-container fluid grid-list-md text-xs-center>
  
  <planilla> </planilla>
  
</v-container>
@endsection
