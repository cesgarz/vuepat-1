@extends('layouts.app')

@section('content')

    <v-container fluid grid-list-md text-xs-center>

    <usuario-lista></usuario-lista>         

    </v-container>

@endsection