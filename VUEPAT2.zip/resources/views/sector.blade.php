@extends('layouts.app')
@section('content')

<v-container fluid grid-list-md text-xs-center>
  
  
  <sector-lista> </sector-lista>
  
  
</v-container>
@endsection
