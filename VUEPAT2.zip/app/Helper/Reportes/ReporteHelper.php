<?php

namespace App\Helper\Reportes;

use Illuminate\Database\Eloquent\Model;

class ReporteHelper extends Model
{
    //
}
