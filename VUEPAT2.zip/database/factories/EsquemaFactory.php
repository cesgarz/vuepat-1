<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Esquema::class, function (Faker $faker) {
    return [
        //
    ];
});
