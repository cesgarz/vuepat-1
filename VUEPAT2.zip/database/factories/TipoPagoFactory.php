<?php

use Faker\Generator as Faker;

$factory->define(App\Models\TipoPago::class, function (Faker $faker) {
    return [
        //
    ];
});
