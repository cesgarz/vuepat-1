<?php

use Faker\Generator as Faker;

$factory->define(App\Models\PersonaEmpleo::class, function (Faker $faker) {
    return [
        //
    ];
});
