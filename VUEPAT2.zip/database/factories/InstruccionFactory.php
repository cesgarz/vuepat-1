<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Instruccion::class, function (Faker $faker) {
    return [
        //
    ];
});
