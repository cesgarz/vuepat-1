<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Ingreso::class, function (Faker $faker) {
    return [
        //
    ];
});
