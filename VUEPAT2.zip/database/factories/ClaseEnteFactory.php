<?php

use Faker\Generator as Faker;

$factory->define(App\Models\ClaseEnte::class, function (Faker $faker) {
    return [
        //
    ];
});
