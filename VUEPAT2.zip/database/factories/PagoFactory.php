<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Pago::class, function (Faker $faker) {
    return [
        //
    ];
});
